<?php
define("URL","http://127.0.0.1/googon/");
?>