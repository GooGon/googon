<?php
#Library
include_once '../config/mainboard.php';
?>

<html>
    <head>
        <title>Blog | GooGon Testing Website</title>
    </head>

    <body>
        <b>Blog</b> &nbsp &nbsp | &nbsp &nbsp
        <a href='../index.php'>Back</a>
        <hr />
    </body>
</html>