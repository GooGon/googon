<?php
#Library
include_once '../config/mainboard.php';
?>

<html>
    <head>
        <title>Contact Me | GooGon Testing Website</title>
    </head>

    <body>
        <b>Contact Me</b> &nbsp &nbsp | &nbsp &nbsp
        <a href='../index.php'>Back</a>
        <hr />
    </body>
</html>