<?php
#Library
include_once '../../config/mainboard.php';
?>

<html>
    <head>
        <title>Curiculum Vitae | GooGon Testing Website</title>
        <style>
            .center {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 50%;
            }
        </style>
    </head>

    <body>
        <img src="../../libs/error-page/page_404.PNG" class="center">
    </body>
</html>