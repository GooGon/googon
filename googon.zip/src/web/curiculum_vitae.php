<?php
#Library
include_once '../config/mainboard.php';
?>

<html>
    <head>
        <title>Curiculum Vitae | GooGon Testing Website</title>
    </head>

    <body>
        <b>Curiculum Vitae</b> &nbsp &nbsp | &nbsp &nbsp
        <a href='../index.php'>Back</a>
        <hr />
    </body>
</html>