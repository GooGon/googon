<footer class="bg-dark text-white">
  <div>
    <div class="text-center" style="padding-bottom: 10px ; padding-top: 20px;">
      <small>&#9400; HafizhHaikal.com</small>
    </div>
    <div class="text-center" style="padding-bottom: 30px ;">
      <small>
        <span>
          <i class="fa-brands fa-facebook-f"></i>
        </span>
        <span>&nbsp; &nbsp;</span>
        <span>
          <i class="fa-brands fa-twitter"></i>
        </span>
        <span>&nbsp; &nbsp;</span>
        <span>
          <i class="fa-brands fa-linkedin"></i>
        </span>
        <span>&nbsp; &nbsp;</span>
        <span>
          <i class="fa-solid fa-envelope"></i>
        </span>
        <span>&nbsp; &nbsp;</span>
        <span>
          <i class="fa-brands fa-github"></i>
        </span>
      </small>
    </div> 
  </div>
</footer>