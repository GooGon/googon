<!-- Metadata-->
<meta charset="utf-8">

<!-- Web Title -->
<title><?php echo $page_title; ?></title>

<!-- Style - General (css) -->
<link rel="stylesheet" href="<?php echo URL; ?>libs/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo URL; ?>libs/fontawesome/css/all.min.css">
<link rel="stylesheet" href="<?php echo URL; ?>assets/css/web.css">

<?php if($page_no == "003"){ ?>
    <link rel="stylesheet" href="<?php echo URL; ?>assets/css/blog.css">
<?php } ?>