<!-- Metadata-->
<meta charset="utf-8">

<!-- Web Title -->
<title>GooGon Testing Website</title>

<!-- Style - General (css) -->
<link rel="stylesheet" href="<?php echo URL; ?>libs/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo URL; ?>libs/fontawesome/css/all.min.css">
<link rel="stylesheet" href="<?php echo URL; ?>assets/css/web.css">